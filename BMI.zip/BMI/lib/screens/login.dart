import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LOGIN extends StatefulWidget {
  const LOGIN({super.key});

  @override
  State<LOGIN> createState() => _LOGINState();
}

class _LOGINState extends State<LOGIN> {
  TextEditingController txtfld = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            SizedBox(height: 20),
            SizedBox(width: 200,
            child: TextField(
              controller: txtfld,
              obscureText: true,
              decoration: InputDecoration(
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(30)),),
                prefixIcon: Icon(Icons.search_sharp),
                suffixIcon: IconButton(
                  onPressed: () {}, icon: const Icon(Icons.clear)),
                label: const Text("username"),
                hintText: ("min 8 charecters"),
                ),
               
              
              obscuringCharacter: "*" ,
              keyboardType: TextInputType.number,
              onChanged:(string) {
                print("this is the text field  $string");
              },
              onEditingComplete: (){
                print("final submission $txtfld");
              },
              
                 

                )
              ),
            

            TextField(),
            Text("Hello stranger this is me", style: GoogleFonts.montserrat(fontWeight: FontWeight.bold),),

            /*
    SizedBox(
    height: 200,
    width: 200,
    child: Card(
      elevation: 30,
      color: Colors.black,
      shadowColor: Colors.blueGrey),
      child: Center(child: Text("This is CARD"),)

    ),
    // Container(height: 200,
    // width: 200,
    // decoration: BoxDecoration(gradient: LinearGradient(colors: colors: [Colors.green, colors.purple, colors.blue])),
    // ),
    );
 CARD!!!!!!!!!!
  ),
  ),*/

  

  const Chip(
    label:Text("FOOD"),
    avatar: CircleAvatar(child: Text("💖")),
    padding: EdgeInsets.all(15),
    deleteIcon: Icon(Icons.delete),),
    
          

  ListView(
    children: 
    [ SizedBox(
      width: double.infinity,
      height: double.infinity ,
      child: Container(
        child: ListTile(
          focusColor: Colors.red,
          leading: Icon(Icons.downhill_skiing_sharp),
          title: Text("data"),
          subtitle: Text("Metadata"),
          
      
        ),
      ),
    )],
  )
       ],
        ),
    ));
  }
}