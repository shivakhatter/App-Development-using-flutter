//import 'package:bmiapp/screens/1stPage.dart';
import 'package:bmiapp/screens/login.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    //theme: ThemeData.dark(),
    debugShowCheckedModeBanner: false,
    home: LOGIN(),
  ));
}