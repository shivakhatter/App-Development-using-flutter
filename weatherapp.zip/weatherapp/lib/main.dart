import 'package:flutter/material.dart';
import 'package:weather/screens/homepage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}