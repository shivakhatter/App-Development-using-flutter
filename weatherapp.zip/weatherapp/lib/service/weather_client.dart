import 'package:dio/dio.dart';

class WeatherClient{
  Dio dio = Dio();
  getWeatherDataFromAPI() async{
    String WeatherURL= "https://api.openweathermap.org/data/2.5/weather?lat=28.42&lon=77.12&appid=e7eb4765e209d098ff5bc2b459981381";
    try{
      var response = await dio.get(WeatherURL);
      print(" response: ${response.data}");
      return response.data;
    }catch(error){
      print("error in fetching data");
    }
  }
}