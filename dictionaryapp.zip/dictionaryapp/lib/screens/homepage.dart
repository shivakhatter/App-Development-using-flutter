import 'package:dict/service/dictClient.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DictClient dClient = DictClient();
  TextEditingController tc = TextEditingController(); 
  String meaning = "null";

  callAPI(q) async{
   await dClient.searchForWord(query: q);
   meaning = await dClient.searchForWord(query: q);
   setState(() {
     
   });
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text("DICTIONARY"),
        centerTitle: true,
      ),
      drawer:  Drawer(
        child: DrawerHeader( 
         //BoxDecoration(color: Color.fromARGB(255, 120, 205, 241)),
        child: SizedBox(height: MediaQuery.of(context).size.height,
        
         child: Center(
           child: Container(child: const Column(children: [
            ListTile(title: Text("Home"),tileColor: Color.fromARGB(255, 225, 238, 243),),
            SizedBox(height: 30),
            ListTile(title: Text("Settings"),tileColor: Color.fromARGB(255, 176, 211, 239)),
            SizedBox(height: 30),
            ListTile(title: Text("My Account"),tileColor: Color.fromARGB(255, 225, 238, 243)),
            SizedBox(height: 30),
            ListTile(title: Text("LogOut"),tileColor: Color.fromARGB(255, 176, 211, 239)),])
           ,),
         ),)),),
     
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: SizedBox(
          // color: Colors.teal,
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              TextField(
                controller: tc,
                decoration: InputDecoration(
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(50))),
                    suffixIcon: IconButton(
                        onPressed: () {}, icon: const Icon(Icons.clear)),
                    label: const Text("Dictionary"),
                    hintText: "Enter a Word to search"),
                // style: ,
                keyboardType: TextInputType.number,
                onChanged: (string) {
                  // print(textfield.text); //controller--> text
                  print("This is the text from the textfield $string");
                },
                onEditingComplete: () {
                  // print(
                  //     // "this is the final submission from the textfield ${txtfld.text}");
                },
              ),
              Padding(
                padding: const EdgeInsets.all(18.0),
                child: OutlinedButton(
                  
                  onPressed: ()
                  {callAPI(tc.text);},
                   child: const Text("Search")),
              ),
            Container(
              color: const Color.fromARGB(255, 134, 189, 235),
              width: 300,
              height: 300,
              child: Center(child:
               Text(meaning, 
               style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
               )
               ),
            )
            ],
          ),
        ),
      ),
    ));
  }
}
