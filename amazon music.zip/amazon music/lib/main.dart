
import 'package:flutter/material.dart';
import 'navbar.dart';
void main(){
  runApp(
    MaterialApp(
      //home: LoadingScreen(),
      theme: ThemeData.dark(),
      home:const NavBar(),

      // initialRoute: '/',
      // routes: {
      //   '/':(context)=>const LoadingScreen(),
      //   '/home':(context)=> HomePage(),
      //   '/home2':(context)=> HomePage2(),
      //   '/profile':(context) => PROFILE(),
      //   '/alexa':(context) => ALEXAPAGE(),
      //   '/search':(context) => SEARCH()
      // },
    )

  );



}