import 'package:flutter/material.dart';
import 'package:musicapp/screens/homePage.dart';
import 'package:musicapp/screens/home_page.dart';
import 'package:musicapp/screens/alexa_page.dart';
import 'package:musicapp/screens/search.dart';
import 'package:musicapp/screens/profile_page.dart';
import 'package:musicapp/screens/loading_screen.dart';


class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = [
    const HomePage2(),
    const LoadingScreen(),
    const HomePage(),
    const HomePage(),
    const PROFILE(),
    const SEARCH(),
    const ALEXAPAGE(),
    //const More(),
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
        body: screens[currentIndexs],

        bottomNavigationBar: BottomNavigationBar(
             backgroundColor: Colors.black,
      
            currentIndex: currentIndexs,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                currentIndexs = value;
              });
            },
            //backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.red,
            selectedFontSize: 13,
            unselectedFontSize: 10,
            
            items: const [

              BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home_sharp)),
              BottomNavigationBarItem(
                  label: "Search", icon: Icon(Icons.search_sharp)),
              //BottomNavigationBarItem(
                  //label: "Downloads", icon: Icon(Icons.download)),
              BottomNavigationBarItem(label: "Coming soon", icon: Icon(Icons.auto_awesome_sharp)),
              BottomNavigationBarItem(
                  label: "Settings", icon: Icon(Icons.settings)),
            ]),
      ),
    );
  }
}