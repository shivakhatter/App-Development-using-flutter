// import 'package:flutter/material.dart';
// void main(){
//   runApp(MaterialApp(
//     theme: ThemeData.dark(),
//     home: Scaffold(appBar: AppBar(
//       leading: const Row( children : [/*Icon(Icons.search_sharp),*/ Icon(Icons.verified_user_rounded)]),
//       title: const Text('YouTube',),
//       titleTextStyle: const TextStyle(fontWeight: FontWeight.bold , color:Color.fromARGB(255, 243, 43, 16), fontSize: 30),
//       centerTitle: true,
//       actions: const [
//         Icon(Icons.search),
//         SizedBox(width: 10,),
//         Icon(Icons.notification_add_sharp),

//       ],
//       ),
//       // body: const Center
//       // (child: Text(
//       //   'Welcome User',
//       //   style: TextStyle(fontSize: 50) , ),
//       //  )

//       body: 
//        const Column(
//         mainAxisAlignment: MainAxisAlignment.spaceAround,
//         children: [
//           Text(' 1st video! ', style: TextStyle(fontSize: 40),
//           ),
//           Text(' 2nd Video! ', style: TextStyle(fontSize: 40),
//           ),
//           Text(' 3rd Video! ', style: TextStyle(fontSize: 40),
//           ),
 
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: [
//               Text('1st row', style: TextStyle(fontSize: 20),
//               ),
//               Spacer(),
//               Text('2nd row', style: TextStyle(fontSize: 20),
//               ),
//               Spacer(),
//               Text('3rd row', style: TextStyle(fontSize: 20),
//               )
            


            
          
//             ],)
//           ],
//           ),  
      
//       ),
//       ),
//   );
// }
 

//import 'package:flutter/material.dart';

// void main() {
//   runApp(
//     MaterialApp(
//         theme: ThemeData.dark(),
//         home: Scaffold( 
//           floatingActionButton: FloatingActionButton(onPressed: (){print('button is pressed');}, child: Icon(Icons.chat)),
//             appBar: AppBar(
//               // leading: const Icon(Icons.battery_1_bar),
//               leading: const Row(
//                 children: [
//                   SizedBox(
//                     width: 20,
//                   ),
//                   Icon(Icons.search),
//                 ],
//               ),
//               title: const Text(
//                 " Flowers ",
//                 style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     color: Color.fromARGB(255, 249, 242, 242),
//                     fontStyle: FontStyle.italic),
//               ),
//               centerTitle: true,
//               actions: const [
//                 Icon(Icons.search),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Icon(Icons.video_call),
//                 Icon(Icons.add)
//               ],
//             ),
//             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
//             body: Column(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: const Color.fromARGB(255, 245, 133, 125),
//                           border: Border.all(width: 5),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/a.jpg"),
//                     ),
//                     const SizedBox(
//                       width: 20,
//                     ),
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: const Color.fromARGB(255, 242, 233, 148),
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/b.png"),
//                     ),
//                     const SizedBox(
//                       width: 20,
//                     ),
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Color.fromARGB(255, 200, 13, 241),
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/c.jpg"),
//                     )
//                   ],
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Color.fromARGB(255, 235, 93, 166),
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/d.jpg"),
//                     ),
//                     const SizedBox(
//                       width: 20,
//                     ),
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Color.fromARGB(255, 125, 243, 127),
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/e.png"),
//                     ),
//                     const SizedBox(
//                       width: 20,
//                     ),
//                     Container(
//                       height: 100,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Colors.blue,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                           child: Image.asset("assets/a.jpg"),
//                     )
//                   ],
//                 ),
//                 const Row(),
//                 const Row()
//               ],
//             ))),
//   );
// }



// FLOATING ACTION BUTTON (FLOATS OVER THE BODY OF THE APP
// WRITTEN IN SCAFFOLD)



import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    //theme: ThemeData.dark(),
    home: Scaffold(
      appBar: AppBar(title: const Text("color app")),
      body: Column(
        children: [
          Container(
            height: 200,
            width: 400,
            decoration: BoxDecoration(color: Colors.purple),
          ),
          Row(
            children: [
              Container(
                height: 200,
                width: 200,
                decoration: BoxDecoration(color: Colors.green),
              ),
              Column(
                children: [
                  Container(
                    height: 50,
                    width: 150,
                    decoration: BoxDecoration(color: Colors.blue),
                  ),
                  Container(
                    height: 150,
                    width: 150,
                    decoration: BoxDecoration(color: Colors.pink),
                  ),
                ],
              ),
          
            ],
          ),
          Container(
            height: 200,
            width: 400,
            decoration: BoxDecoration(color: Colors.orange),)
        ],
      ),
    ),
  ));
}