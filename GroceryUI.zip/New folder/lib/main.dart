import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
        home: Scaffold(floatingActionButton: FloatingActionButton(onPressed: (){print('button is pressed');}, child: Icon(Icons.chat)),

            appBar: AppBar(
              leading: const Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Icon(Icons.search),
                ],
              ),
              title: const Text(
                " Fruitopia ",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,),
              ),
              centerTitle: true,
              actions: const [
                Icon(Icons.search),
                SizedBox(
                  width: 20,
                ),
                Icon(Icons.shopping_basket_sharp),
                Icon(Icons.add)
              ],
            ),


            body: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color :  Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/cherry.jpg"),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/dragon.jpg"),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/pear.jpg"),
                    )
                  ],
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/mango.jpg"),       
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/pine.jpg"),        
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 54, 244, 76),
                          border: Border.all(width: 1),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(20))),
                      child: Image.asset("assets/orange.jpg"),
                    )
                  ],
                ),
                Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 130,
                width: 390,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 54, 244, 76),
                  border: Border.all(width: 1),
                  borderRadius:(
                    const BorderRadius.all(Radius.circular(20))
                    
                  ),
                ),
                child: Padding(
                  // Following padding to give space around the icon and text
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset(
                        'assets/apple.jpg',
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Text(
                        "This is an apple!",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
         
                     const SizedBox(
                      width: 20,
                    ),
              ],),
            Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 130,
                width: 390,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 54, 244, 76),
                  border: Border.all(width: 1),
                  borderRadius:(
                    const BorderRadius.all(Radius.circular(20))
                    
                  ),
                ),
                child: Padding(
                  // Following padding to give space around the icon and text
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset(
                        'assets/peach.jpg',
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Text(
                        "This is a peach!",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
            ],
          ),



                const Row(),
                const Row()
              ],
            ))),
  );
}