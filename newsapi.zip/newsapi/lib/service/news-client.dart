import 'package:dio/dio.dart';

class NewsClient {
  Dio dio = Dio();

  getNewsDataFromAPI() async {
    String newsURL =
        "https://newsapi.org/v2/top-headlines?country=in&apiKey=84d5f839d70340418f85fb3aafdbd6c2";
    try {
      var response = await dio.get(newsURL);
      print("this is the news data from the API ${response.data}");
      return response.data;
    } catch (error) {
      print("Error in fetchind data from API");
    }
  }
}