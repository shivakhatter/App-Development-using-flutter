import 'package:flutter/material.dart';
import 'package:newsapp/screens/homepage.dart';

void main(){
  runApp(const MaterialApp
  (
    home: HomePage(), )
  );

}