import 'package:flutter/material.dart';


void main() {
  runApp(MaterialApp(
  theme: ThemeData.dark(),
    home: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 219, 45, 14),
          leading: Image.asset('assets/logo.png'),
          title: const Text(
            '       TED APP',
          ),
          actions: const [
            Icon(Icons.search_sharp),
            SizedBox(
              width: 20,
            ),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.add_location_alt_sharp),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.circle_notifications_sharp),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.account_circle_sharp),
            SizedBox(
              width: 20,
            ),
          ],
        ),
        body: 
           Column(
            children:  [
              Stack(
                children: [
                  Container(
                  width: 390,
                  height: 200,
                  child: Image.asset('assets/1.jpg'),   
              ),             
              Positioned(
                left: 8,
                bottom: 8,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    // color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "TEDx June edition talk-1",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                ),
              ),
                ],
              ),
            
             Stack(
                children: [
                  Container(
                width: 390,
                height: 200,
                decoration: const BoxDecoration(
                    color: Colors.red,
                    ),
                child: Image.asset('assets/2.jpg'),
              ),
              Positioned(
                left: 8,
                bottom: 8,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    // color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "TEDx July motivational talk",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                 ),
                ),
              ),
                ],
              ),
             
            
              Stack(
                children: [
                   Container(
                width: 390,
                height: 200,
                decoration: const BoxDecoration(
                 color: Colors.red,
                  ),
                child: Image.asset('assets/3.jpg'),
              ),
              Positioned(
                left: 8,
                bottom: 8,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    // color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "Taylor swift inspired motivation by debbie ",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
                ],
              )


              
             

              
            ]
          ),
    )
   ),
    );
  
  
}